Arcade Wallet
Live website: https://arcade-wallet-rho.vercel.app/

Upload the static website files to your hosting provider. Google login and balances use the existing Supabase project and require an internet connection. For a different hosting address, configure its URL in Supabase authentication settings.

schema.sql is the backend setup source, already installed in your existing Supabase project; do not rerun it there. Google OAuth secrets remain in Supabase and are not included in this download.
