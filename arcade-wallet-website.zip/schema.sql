begin;
create schema if not exists wallet_private;
revoke all on schema wallet_private from public;
create table wallet_private.accounts(id uuid primary key references auth.users(id),username text not null unique check(username ~ '^[a-z0-9_]{3,20}$'),cash bigint not null default 100000 check(cash>=0),start bigint not null default 100000,hold jsonb not null default '{"BTC":0,"ETH":0,"SOL":0,"GOLD":0,"EQNR":0}',seen timestamptz not null default now());
create table wallet_private.ledger(id uuid primary key,sender uuid not null references wallet_private.accounts(id),recipient uuid references wallet_private.accounts(id),kind text not null,asset text,cents bigint not null,at timestamptz not null default now());
create index wallet_seen on wallet_private.accounts(seen);
create index wallet_ledger_sender on wallet_private.ledger(sender,at desc);
create index wallet_ledger_recipient on wallet_private.ledger(recipient,at desc);
alter table wallet_private.accounts enable row level security;
alter table wallet_private.ledger enable row level security;
revoke all on all tables in schema wallet_private from public,anon,authenticated;
create function wallet_private.market() returns jsonb language sql stable set search_path='' as $$
select jsonb_object_agg(k,v*exp(.7*sin(t*.018+i*2)+.25*sin(t*.19+i)+.08*sin(t*1.2+i*4))) from (values('BTC',62000.0,0),('ETH',2450.0,1),('SOL',150.0,2),('GOLD',2650.0,3),('EQNR',25.5,4)) b(k,v,i) cross join (select extract(epoch from statement_timestamp())/1.8 as t) c;
$$;
create function wallet_private.snapshot() returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); me jsonb; online jsonb; history jsonb;
begin
if u is null then raise exception 'Please sign in.'; end if;
update wallet_private.accounts set seen=now() where id=u;
select jsonb_build_object('username',a.username,'cash',a.cash,'start',a.start,'hold',a.hold::text) into me from wallet_private.accounts a where id=u;
select coalesce(jsonb_agg(jsonb_build_object('username',username) order by username),'[]') into online from (select username from wallet_private.accounts where seen>now()-interval '25 seconds' and id<>u limit 100) q;
select coalesce(jsonb_agg(row_to_json(q) order by q.at desc),'[]') into history from (select l.kind,l.cents,l.asset,(extract(epoch from l.at)*1000)::bigint at,s.username sender,r.username recipient from wallet_private.ledger l join wallet_private.accounts s on s.id=l.sender left join wallet_private.accounts r on r.id=l.recipient where l.sender=u or l.recipient=u order by l.at desc limit 30) q;
return jsonb_build_object('me',me,'online',online,'history',history,'prices',wallet_private.market());
end $$;
create function wallet_private.perform(payload jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); a wallet_private.accounts%rowtype; r uuid; action text:=payload->>'action'; asset text:=payload->>'asset'; cents bigint; qty numeric; owned numeric; price numeric; request_id uuid; name text;
begin
if u is null then raise exception 'Please sign in.'; end if;
perform pg_advisory_xact_lock(754132);
if action='profile' then
 name:=lower(payload->>'username'); if name is null or name !~ '^[a-z0-9_]{3,20}$' then raise exception 'Use 3–20 letters, numbers or underscores.'; end if;
 if exists(select 1 from wallet_private.accounts where id=u) then raise exception 'Account already exists.'; end if;
 insert into wallet_private.accounts(id,username) values(u,name); return jsonb_build_object('ok',true);
end if;
request_id:=(payload->>'id')::uuid; if request_id is null then raise exception 'Invalid request.';end if;
if exists(select 1 from wallet_private.ledger where id=request_id) then raise exception 'Request already processed. Refresh your balance.';end if;
select * into a from wallet_private.accounts where id=u for update; if not found then raise exception 'Choose a username first.';end if;
if action not in ('buy','sell','sellAll','send') or action is null then raise exception 'Invalid action.';end if;
if action<>'send' then
 if asset is null or asset not in ('BTC','ETH','SOL','GOLD','EQNR') then raise exception 'Unknown asset.';end if;
 price:=(wallet_private.market()->>asset)::numeric;owned:=(a.hold->>asset)::numeric;
end if;
if action='sellAll' then
 if owned<=0 then raise exception 'You do not own any of this asset.';end if;
 cents:=round(owned*price*100)::bigint;
 update wallet_private.accounts set cash=cash+cents,hold=jsonb_set(hold,array[asset],'0') where id=u;
 action:='sell';
else
 if (payload->>'amount') is null or (payload->>'amount') in ('NaN','Infinity','-Infinity') then raise exception 'Enter a valid amount.';end if;
 cents:=round((payload->>'amount')::numeric*100)::bigint;
 if cents<=0 or cents>100000000000 then raise exception 'Enter a valid amount.';end if;
 if action in ('buy','send') and a.cash<cents then raise exception 'Not enough available cash.';end if;
 if action='send' then
 select id into r from wallet_private.accounts where username=lower(payload->>'recipient') and id<>u and seen>now()-interval '25 seconds';
 if r is null then raise exception 'Choose another online user.';end if;
 update wallet_private.accounts set cash=cash-cents,start=start-cents where id=u;
 update wallet_private.accounts set cash=cash+cents,start=start+cents where id=r;
 else
 qty:=cents/100.0/price;
 if action='sell' and qty>owned then raise exception 'You do not own enough.';end if;
 update wallet_private.accounts set cash=cash+case when action='buy' then -cents else cents end,hold=jsonb_set(hold,array[asset],to_jsonb(owned+case when action='buy' then qty else -qty end)) where id=u;
 end if;
end if;
insert into wallet_private.ledger(id,sender,recipient,kind,asset,cents) values(request_id,u,r,action,case when action='send' then null else asset end,cents);
return jsonb_build_object('ok',true);
end $$;
revoke all on all functions in schema wallet_private from public,anon,authenticated;
grant usage on schema wallet_private to authenticated;
grant execute on function wallet_private.snapshot() to authenticated;
grant execute on function wallet_private.perform(jsonb) to authenticated;
create function public.wallet_snapshot() returns jsonb language sql security invoker set search_path='' as $$select wallet_private.snapshot()$$;
create function public.wallet_action(payload jsonb) returns jsonb language sql security invoker set search_path='' as $$select wallet_private.perform(payload)$$;
revoke all on function public.wallet_snapshot() from public,anon;
revoke all on function public.wallet_action(jsonb) from public,anon;
grant execute on function public.wallet_snapshot() to authenticated;
grant execute on function public.wallet_action(jsonb) to authenticated;
commit;
select 'Wallet schema ready' as result;